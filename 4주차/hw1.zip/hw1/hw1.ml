type day = SUN | MON | TUE | WED | THU | FRI | SAT
type grade = Aplus | A | Bplus | B | Cplus | C | Dplus | D | F
    
let student_number = -1;;
let email = "";;
let phone_number = "";;
let favorite_day = FRI;;
let expected_grade = Aplus;;
let is_male = false;;
let result = 0.0;;
