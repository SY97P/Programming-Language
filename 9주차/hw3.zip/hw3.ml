(* hw3.ml *)

exception NotImplemented

let rec sum _ = raise NotImplemented
let rec fac _ = raise NotImplemented
let rec fib _ = raise NotImplemented
let rec gcd _ _ = raise NotImplemented
let rec max _ = raise NotImplemented

type tree = Leaf of int | Node of int * tree * tree

let rec sum_tree _ = raise NotImplemented
let rec depth _ = raise NotImplemented
let rec bin_search _ _ = raise NotImplemented
    
type exp =
  INT of int
| ADD of exp * exp
| SUB of exp * exp
| MUL of exp * exp
| DIV of exp * exp
| MOD of exp * exp

let rec interp _ = raise NotImplemented

type formula =
  True
| False
| Neg of formula
| Or of formula * formula
| And of formula * formula
| Imply of formula * formula

let rec eval _ = raise NotImplemented
