exception NotImplemented

let rec list_add _ _ = raise NotImplemented
let rec insert _ _ = raise NotImplemented 
let rec insort _ = raise NotImplemented
let rec ltake _ _ = raise NotImplemented
let rec lall _ _ = raise NotImplemented
let rec lmap _ _ = raise NotImplemented
let rec lfilter _ _ = raise NotImplemented
let rec ltabulate _ _ = raise NotImplemented
let rec lrev _ = raise NotImplemented
let rec lconcat _ = raise NotImplemented 
let rec lfoldl _ _ _ = raise NotImplemented 	
let rec lzip _ _ = raise NotImplemented
let rec split _ = raise NotImplemented
let rec cartprod _ _ = raise NotImplemented

