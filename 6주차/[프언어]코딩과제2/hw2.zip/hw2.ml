let sum n = 0;;

let circle r = 0.0;;

let concat s = "";;

let xor x y = true;;

let triangle x y z = true;;

let int_if_then_else b x y = 0;;

let sum_of_fun_val a b c d e = 0;;

let comp3 a b c d = 0;;

let string2 s = "";;

let string256 s = "";;
